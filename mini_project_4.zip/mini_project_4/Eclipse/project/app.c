#include "icu.h"
#include "ultrasonic.h"
#include "gpio.h"
#include "lcd.h"
#include "util/delay.h"
#include "atmega_16_regs.h"

int main (void){
	Icu_Config configuration ={Normal_mode,Frequency_Pre_8,Normal_Wave,1};
	uint16 distance=0;
	SREG_REG|=(1<<7);
	Ultrasonic_init(&configuration);
	LCD_init();
	LCD_sendString((uint8*)"Distance= ");

	while(1){
		LCD_moveCursor(1, 11);

		distance=Ultrasonic_readDistance();
		if(distance>100){
			LCD_intgerToString(distance);
			LCD_sendString((uint8*)"cm");
		}
		else{
			LCD_intgerToString(distance);
			LCD_sendString((uint8*)" cm");
		}
	}
	return 0;
}
