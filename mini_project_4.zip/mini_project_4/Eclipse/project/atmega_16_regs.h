 /******************************************************************************
 *
 * Module: atmega16_REGS
 *
 * File Name: atmega_16_regs.h
 *
 * Description: Header file for including registers of atmega 16
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/
#ifndef GPIO_MODULE_H_
#define GPIO_MODULE_H_

#include "std_types.h"

/*******************************************************
*			MACROS FOR REGISTERS OF IO				   *
*******************************************************/

/*===========================================================================================================*/
/* PORTA */
#define PORTA_REG		(*(volatile uint8 * const)(0x003B))

#define DDRA_REG		(*(volatile uint8 * const)(0x003A))

#define PINA_REG		(*(volatile const uint8 * const)(0x0039))

/* PORTB*/
#define PORTB_REG		(*(volatile uint8 * const)(0x0038))

#define DDRB_REG		(*(volatile uint8 * const)(0x0037))

#define PINB_REG		(*(volatile const uint8 * const)(0x0036))

/* PORTC*/
#define PORTC_REG		(*(volatile uint8 * const)(0x0035))

#define DDRC_REG		(*(volatile uint8 * const)(0x0034))

#define PINC_REG		(*(volatile const uint8 * const)(0x0033))

/* PORTD*/
#define PORTD_REG		(*(volatile uint8 * const)(0x0032))

#define DDRD_REG		(*(volatile uint8 * const)(0x0031))

#define PIND_REG		(*(volatile const uint8 * const)(0x0030))
/*===========================================================================================================*/
/*******************************************************************************************
 * 								TIMERS													   *
 ******************************************************************************************/
/*TIMERS GEN*/
#define TIMSK_REG (*(volatile uint8 *const)(0x59))
#define TIFR_REG (*(volatile uint8 *const)(0x58))
#define MCUCR_REG (*(volatile uint8 *const)(0x55))
#define MCUCSR_REG (*(volatile uint8 *const)(0x54))


/*TIMER0 REGS*/
#define OCR0_REG (*(volatile uint8 *const)(0x5C))
#define TCCR0_REG (*(volatile uint8 *const)(0x53))
#define TCNT0_REG (*(volatile uint8 *const)(0x52))

/*TIMER0 REGS*/
#define OCR1A_REG (*(volatile uint16 *const)(0x4A))
#define OCR1B_REG (*(volatile uint16 *const)(0x48))
#define TCCR1A_REG (*(volatile uint8 *const)(0x4F))
#define TCCR1B_REG (*(volatile uint8 *const)(0x4E))
#define TCNT1_REG (*(volatile uint16 *const)(0x4C))
#define ICR1_REG (*(volatile uint16 *const)(0x46))

/*TIMER0 REGS*/
#define OCR2_REG (*(volatile uint8 *const)(0x43))
#define TCCR2_REG (*(volatile uint8 *const)(0x45))
#define TCNT2_REG (*(volatile uint8 *const)(0x44))

#define SFIOR_REG (*(volatile uint8*const)(0x50))

/*WDT REGS*/
#define WDTCR_REG (*(volatile uint8 *const)(0x41))


/*===========================================================================================================*/
/*******************************************************************************************
 * 								INTERRUPTS													   *
 ******************************************************************************************/
/*INTERRUPTS*/
#define GICR_REG (*(volatile uint8 *const)(0x5B))
#define GIFR_REG (*(volatile uint8 *const)(0x5A))

/*===========================================================================================================*/
/*******************************************************************************************
 * 								ADC REGS													   *
 ******************************************************************************************/
/*ADC REGS*/
#define ADMUX_REG (*(volatile uint8 *const)(0x27))
#define ADCSRA_REG (*(volatile uint8 *const)(0x26))
#define ADC_REG (*(volatile uint16 *const)(0x24))

/*===========================================================================================================*/
/*******************************************************************************************
 * 								COMMUNICATION PROTOCOLS REGS													   *
 ******************************************************************************************/
/*UART*/
#define UDR_REG (*(volatile uint8 *const)(0x2C))
#define UCSRA_REG (*(volatile uint8 *const)(0x2B))
#define UCSRB_REG (*(volatile uint16 *const)(0x2A))
#define UCSRC_REG (*(volatile uint8 *const)(0x40))
#define UBRRH_REG (*(volatile uint8 *const)(0x40))
#define UBRRL_REG (*(volatile uint8 *const)(0x29))

/*SPI REGS*/
#define SPDR_REG (*(volatile uint8 *const)(0x2F))
#define SPSR_REG (*(volatile uint8 *const)(0x2E))
#define SPCR_REG (*(volatile uint16 *const)(0x2D))


/************************************************************************************
 * 										SREG										*
 ***********************************************************************************/
#define SREG_REG  (*(volatile uint16 *const)(0x5F))


#endif /* GPIO_MODULE_H_ */
