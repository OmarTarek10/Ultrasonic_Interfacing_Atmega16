 /******************************************************************************
 *
 * Module: GPIO
 *
 * File Name: gpio.h
 *
 * Description: Header file for GPIO driver for AVR
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/
#ifndef gpio_h_
#define gpio_h_

#include "std_types.h"
/****************************************************
 * 					Definitions						*
 ***************************************************/
#define NUM_OF_PORTS 4
#define NUM_OF_PINS_PER_PORT 8

/*PINS IDS*/
#define PIN0_ID                0
#define PIN1_ID                1
#define PIN2_ID                2
#define PIN3_ID                3
#define PIN4_ID                4
#define PIN5_ID                5
#define PIN6_ID                6
#define PIN7_ID                7

/*PORTS_ID*/
#define PORTA_ID 0
#define PORTB_ID 1
#define PORTC_ID 2
#define PORTD_ID 3

/*BITS HEX*/
#define FIRST_BIT 1
#define FIRST_TWO_BITS 2
#define FIRST_THREE_BITS 3
#define FIRST_FOUR_BITS 4
#define FIRST_FIVE_BITS 5
#define FIRST_SIX_BITS 6
#define FIRST_SEVEN_BITS 7
#define FIRST_EIGHT_BITS 8

/******************************************************
 * 					New_Types						  *
 *****************************************************/

typedef enum {
	PIN_INPUT,PIN_OUTPUT
}GPIO_PinDirectionType;

typedef enum {
	PORT_INPUT=0x00,PORT_OUTPUT=0xff
}GPIO_PortDirectionType;

typedef enum {
	PORTLOW,PORTHIGH=0xff
}GPIO_PortOutputValue;

/***************************************************************************
 * 							Function PROTOTYPES						   *
 **************************************************************************/

/*-------------------------------------------------------------------------*/
void GPIO_setupPinDirection(uint8 port_num,uint8 pin_num,GPIO_PinDirectionType direction);
/*
 For Setting up direction for each pin alone
 */
/*--------------------------------------------------------------------------*/
void GPIO_setupPortDirection(uint8 port_num,GPIO_PinDirectionType direction);
/*
 For setting up direction of port directly
 */
/*--------------------------------------------------------------------------*/
void GPIO_setupSpecPinDirection(uint8 port_num,uint8 pins,GPIO_PinDirectionType direction);
/*
 For Writing a port Value
 */
/*--------------------------------------------------------------------------*/
void GPIO_writePin(uint8 port_num,uint8 pin_num,uint8 value);
/*
 For Writing a pin value
 */
/*--------------------------------------------------------------------------*/
void GPIO_writeSpecPin(uint8 port_num,uint8 value);
/*
 For Writing a port Value
 */
/*--------------------------------------------------------------------------*/
void GPIO_writePort(uint8 port_num,GPIO_PortOutputValue value);
/*
 For Writing a specific value to the Port
 */
/*--------------------------------------------------------------------------*/
uint8 GPIO_readPin(uint8 port_num,uint8 pin_num);
/*
 For reading the value of a pin
 */
/*--------------------------------------------------------------------------*/
uint8 GPIO_readPort(uint8 port_num);
/*
 for reading the port value
 */
/*--------------------------------------------------------------------------*/


#endif

