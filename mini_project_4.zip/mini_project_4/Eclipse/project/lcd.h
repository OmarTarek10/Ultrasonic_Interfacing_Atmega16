 /******************************************************************************
 *
 * Module: LCD
 *
 * File Name: lcd.h
 *
 * Description: Driver for LCD 8 bit mode
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/
#ifndef LCD_H_
#define LCD_H_

#include "atmega_16_regs.h"
#include "std_types.h"

/**********************************************
 * 				DEFINES						  *
 *********************************************/
#define LCD_ROWS 2
#define LCD_NO_OF_CHARACTERS 16

#define LCD_POWER_PORT PORTB_ID
#define LCD_RS PIN0_ID
#define LCD_RW PIN1_ID
#define LCD_ENABLE PIN2_ID

#define LCD_DATA_PORT PORTA_ID


#define CMD_CLEAR_DISPLAY 0x01
#define CMD_RETURN_HOME 0x02
#define CMD_DECREMENT_CURSOR 0x04
#define	CMD_INCREMENT_CURSOR 0x06
#define CMD_SHIFT_DISPLAY_RIGHT 0x05
#define CMD_SHIFT_DISPLAY_LEFT 0x07
#define CMD_DISPOFF_CURSOROFF 0x08
#define CMD_DISPOFF_CURSORON 0x0A
#define CMD_DISPON_CURSOROOFF 0x0C
#define CMD_DISPON_CURSOROON 0x0E
#define CMD_DISPON_CURSOROBLINKING 0x0F
#define CMD_SHIFT_CURSOR_LEFT 0x10
#define CMD_SHIFT_CURSOR_RIGHT 0x14
#define CMD_SHIFT_DISP_ALL_LEFT 0x18
#define CMD_SHIFT_DISP_ALL_RIGHT 0x1C
#define CMD_FORCE_CURSOR_BEG_LINE1 0x80
#define CMD_FORCE_CURSOR_BEG_LINE2 0xC0
#define CMD_2LINES_5x8_MATRIX 0x38
#define LCD_SET_CURSOR_LOCATION 0x80
/**********************************************
 * 				FUNCTION PROTOTYPES				  *
 *********************************************/
void LCD_init(void);
void LCD_sendCommand(uint8 a_command);
void LCD_sendCharacter(const uint8 a_character);
void LCD_sendString(const uint8 *a_string);
void LCD_moveCursor(uint8 a_row,uint8 a_column);
void LCD_clearScreen(void);
void LCD_displayStringRowColumn(uint8 row,uint8 col,const uint8 *Str);
void LCD_intgerToString(int data);

#endif /* LCD_H_ */
