 /******************************************************************************
 *
 * Module: ICU
 *
 * File Name: icu.h
 *
 * Description: ICU driver for AVR
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/
#ifndef ICU_H_
#define ICU_H_

#include "std_types.h"
#define ICU_INTERRUPT_EN

/*********************************************
 * 		    	NEW TYPES					 *
 ********************************************/
typedef enum {
	Frequency_Pre_0=0x00,Frequency_Pre_1=0x01,Frequency_Pre_8=0x02,\
	Frequency_Pre_64=0x03,Frequency_Pre_256=0x04,Frequency_Pre_1024=0x05,
} Frequency_Prescaler_Tccr1b;

typedef enum{
	Normal_mode=0x0C,Compare_Mode_A=0x8C,Compare_Mode_B=0x1C
} Operating_Mode_Tccr1a;

typedef enum{
	Normal_Wave=0x00,Ctc_Wave=0x08
} Waveform_Mode_Tccr1b;


/*
 * configuration struct that takes:
 * the mode of operation
 * the prescaler
 * the wavetype
 * the edge to work with
 */
typedef struct {
	Operating_Mode_Tccr1a Operation;
	Frequency_Prescaler_Tccr1b Prescaler;
	Waveform_Mode_Tccr1b Wave;
	uint8 EdgeType;
}Icu_Config;


/******************************************
 * 				Functions				  *
 *****************************************/
/*******************************************************************************
� Description
       -Sets the wanted edge
       -Mode of operation
       -Chooses the wanted clock
       -Makes Timer1 start counting from 0
       -Enables Timer1 input capture interrupt bit enable to enable interrupts
       -Makes PIN6 in PORTD as INPUT
� Inputs:
		 -config_Ptr: pointer to structure ICU_Configurations to choose the wanted
		 	 	 	  edge and clock
� Return: None
 *******************************************************************************/
void ICU_init (const Icu_Config *s_configurtion);

/*******************************************************************************
� Description
       -Change the edge the ICU makes an interrupt when occurs
       (Note: if you want to use ICU, you must use the ICU_init function
� Inputs:
		 -edge: Whether RISING or FALLING
� Return: None
 *******************************************************************************/
void ICU_setEdge (uint8 a_edgeType);

/*******************************************************************************
� Description
       -enable noise cancelling.
� Inputs: noise cancelling enable or disable variable
� Return: None
 *******************************************************************************/
void ICU_noiseCancelling (uint8 a_noiseVal);

/*******************************************************************************
� Description
       -return the value of the icr1 value.
� Inputs: None
� Return: icr1 value
 *******************************************************************************/
uint16 ICU_getIcrValue(void);

/*******************************************************************************
� Description
       -set call buck function passed from user
� Inputs: function that executes with isr
� Return: None
 *******************************************************************************/
void ICU_setCallBack(void(*a_ptr)(void));

/*******************************************************************************
� Description
       -Stop ICU from working
� Inputs: None
� Return: None
 *******************************************************************************/
void ICU_DeInit(void);

/*******************************************************************************
� Description
       -Makes TCNT1 = 0 (Makes TIMER1 count from 0)
� Inputs: None
� Return: None
 *******************************************************************************/
void Icu_clearTimerValue(void);

#endif /* ICU_H_ */
