 /******************************************************************************
 *
 * Module: ICU
 *
 * File Name: icu.c
 *
 * Description: ICU driver for AVR
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/
#include "icu.h"
#include "atmega_16_regs.h"
#include "gpio.h"
#include "avr/interrupt.h" /* ICU works using interrupts */


static volatile void (*g_Ptr)(void)=NULL_PTR;
ISR(TIMER1_CAPT_vect){
	if(g_Ptr!=NULL_PTR){
		(*g_Ptr)();
	}
}

/*******************************************************************************
� Description
       -Sets the wanted edge
       -Mode of operation
       -Chooses the wanted clock
       -Makes Timer1 start counting from 0
       -Enables Timer1 input capture interrupt bit enable to enable interrupts
       -Makes PIN6 in PORTD as INPUT
� Inputs:
		 -config_Ptr: pointer to structure ICU_Configurations to choose the wanted
		 	 	 	  edge and clock
� Return: None
 *******************************************************************************/
void ICU_init (const Icu_Config *s_configurtion){
	DDRD_REG &= ~(1<<PIN6_ID);
	TCCR1A=(s_configurtion->Operation);
	TCCR1B=(s_configurtion->Prescaler)|(s_configurtion->Wave);
	TCCR1B=(TCCR1B_REG&0xBF)|(((s_configurtion->EdgeType)&1)<<6);
	TCNT1=0;
	ICR1=0;

/*
 Enable interrupt if defined
 */

#ifdef ICU_INTERRUPT_EN
	TIMSK|=0x20;
#endif
}

/*******************************************************************************
� Description
       -Change the edge the ICU makes an interrupt when occurs
       (Note: if you want to use ICU, you must use the ICU_init function
� Inputs:
		 -edge: Whether RISING or FALLING
� Return: None
 *******************************************************************************/
void ICU_setEdge (const uint8 a_edgeType){
	TCCR1B=(TCCR1B_REG&0xBF)|((1&a_edgeType)<<6);
}

/*******************************************************************************
� Description
       -enable noise cancelling.
� Inputs: noise cancelling enable or disable variable
� Return: None
 *******************************************************************************/
void ICU_noiseCancelling (uint8 a_noiseVal){
	TCCR1B=(TCCR1B_REG&0x7F)|((1&a_noiseVal)<<7);
}

/*******************************************************************************
� Description
       -return the value of the icr1 value.
� Inputs: None
� Return: icr1 value
 *******************************************************************************/
uint16 ICU_getIcrValue(void){
	return ICR1;
}

/*******************************************************************************
� Description
       -Makes TCNT1 = 0 (Makes TIMER1 count from 0)
� Inputs: None
� Return: None
 *******************************************************************************/
void Icu_clearTimerValue(void)
{
	TCNT1 = 0;
}

/*******************************************************************************
� Description
       -set call buck function passed from user
� Inputs: function that executes with ISR
� Return: None
 *******************************************************************************/
void ICU_setCallBack(void(*a_ptr)(void)){
	  g_Ptr=a_ptr;
}

/*******************************************************************************
� Description
       -Stop ICU from working
� Inputs: None
� Return: None
 *******************************************************************************/
void ICU_DeInit(void){
	TCCR1A= 0;
	TCCR1B= 0;
	TCNT1= 0;
	ICR1= 0;
	TIMSK&= ~(1<<5);
}
